import {takeEvery,takeLatest,throttle,select} from 'redux-saga/effects'
import axios from 'axios'

export function* defSaga(){
    yield takeEvery('takeEvery',function*(){
        //const state = yield select(state => state.user)
        const state = yield select()

        console.log(state);
        
    })
    yield takeLatest('takeLatest',function*(){
        console.log('takeLatest');
        
    })
    yield throttle(0,'throttle',function*(){
        console.log('throttle'); 
        
    })
}