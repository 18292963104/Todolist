export function defReducer(state={},action){
    return Object.assign({},state,action);
    console.log(state);
    
    return state
}