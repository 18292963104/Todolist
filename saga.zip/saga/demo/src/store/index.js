import {createStore, applyMiddleware} from 'redux'
import {defReducer} from './reducers'
import {defSaga} from './saga'
import createSagaMiddleware from 'redux-saga'

const sagaMiddleware = createSagaMiddleware();

export default createStore(defReducer,{},applyMiddleware(sagaMiddleware))
sagaMiddleware.run(defSaga)
