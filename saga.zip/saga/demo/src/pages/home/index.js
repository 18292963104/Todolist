import React, { Component } from 'react'

import {connect} from 'react-redux'

class Home extends Component {
    handleClicktakeEvery=()=>{
        this.props.dispatch({
            type:'takeEvery',
            user :{
                name : 'mi',
                age : 13
            }
        })
    }
    handleClicktakeLatest=()=>{
        this.props.dispatch({
            type:'takeLatest',
            user :{
                name : 'li',
                age : 16
            }
        })
    }    
    handleClickthrottle=()=>{
        this.props.dispatch({
            type:'throttle',
            user :{
                name : 'ya',
                age : 18
            }
        })
    }
    render() {
        return (
            <div>
                <button onClick={this.handleClicktakeEvery}>click to sent takeEvery action</button>
                <button onClick={this.handleClicktakeLatest}>click to sent takeLatest action</button>
                <button onClick={this.handleClickthrottle}>click to sent throttle action</button>

            </div>
        );
    }
}

export default connect()(Home);
